<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\DB;
use Validator;
use Auth;
class MainController extends Controller
{
    function index(){
        return view('login');
    }
    function register(){
        return view('register');
    }

    public function registration(Request $request){
        $firstname = $request->input('firstname');
        $lastname = $request->input('lastname');
        $username = $request->input('username');
        $password = $request->input('password');
        DB::insert('insert into register(firstname,lastname,username,password) values(?,?,?,?)',[$firstname,$lastname,$username,$password]);
        // DB::table('register')->insert(
            // ['firstname' => $request->input('firstname'), 'lastname' => $request->input('lastname'),'username' => $request->input('username'),'password' => $request->input('password')]
        // $arr = [
        //     'firstname' => $request->firstname,
        //     'lastname' =>$request->lastname,
        //     'username' => $request->username,
        //     'password' => $request->password
        // ];
        // // print_r($arr);
        // DB::table('register')->insert($arr);    

    }
}
